pluginManagement {
    repositories {
        google()
        gradlePluginPortal()
        mavenCentral()
    }
}

rootProject.name = "MarvelTPTaller"
include(":androidApp")
include(":shared")