package com.example.marveltptaller

class Keys {
    val kPrivate: String  = "789ce3475d1816f239b2794eec352069ee7734d2"
    val kPublic: String = "8f155813be4c5d17cd84387126686680"
    }