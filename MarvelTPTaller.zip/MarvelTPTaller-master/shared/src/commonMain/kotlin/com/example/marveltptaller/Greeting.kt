package com.example.marveltptaller

class Greeting {
    fun greeting(): String {
        return "Hello, ${Platform().platform}!"
    }
}