package com.example.marveltptaller

expect class Platform() {
    val platform: String
}