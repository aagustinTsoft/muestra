package TestUnitarios
import kotlin.test.Test
import kotlin.test.assertEquals

class TestUnitarios {
    @Test
    fun Test_suma() {
        val calculadora = Calculadora()
        val resultado = calculadora.sumar(3, 2)
        assertEquals(5, resultado)
    }
}